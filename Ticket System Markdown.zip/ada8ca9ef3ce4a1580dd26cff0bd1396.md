**Ticket System**

Step 1: In Microsoft Azure, create a Resource Group, Virtual Network,
and Network Security Group.

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image1.png){width="3.274900481189851in"
height="3.6638888888888888in"}![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image2.png){width="3.5120002187226596in"
height="2.794890638670166in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image3.png){width="3.56in"
height="2.78959864391951in"}

*Creating a **Resource Group**, **VNet**, and **NSG** before a **Virtual
Machine** allows an organized and secure environment.*

-   ![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image4.png){width="6.347825896762904in"
    height="1.6791896325459317in"}Create Inbound Security Rule in NSG to
    Default-Deny all Inbound Traffic for better security in my VNet.

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image5.png){width="3.36in"
height="2.4751279527559054in"}Step 2. Create a Virtual Machine with SSH
through my local machine public key authentication & assigned NIC to my
Network Security Group.

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image6.png){width="2.8480008748906385in"
height="2.6184120734908136in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image7.png){width="3.16799978127734in"
height="2.5838670166229223in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image8.png){width="3.892661854768154in"
height="2.3040179352580927in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image9.png){width="5.29599956255468in"
height="2.9682491251093612in"}

*I got my **SSH ***

***key** pair via*

***PowerShell***

*by **ssh-keygen***

*command.*

Step 3. Create Inbound Security Rule in NSG to allow SSH connection from
my IP Addresss. After, test SSH connection to my VM through PowerShell.

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image10.png){width="6.5in"
height="2.001388888888889in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image11.png){width="3.4890791776028in"
height="3.6320002187226597in"}

> *I am now **connected** & in*
>
> ***control** of my **Azure***

***Virtual Machin**e via **SSH***

*on **PowerShell**. Apply*

***updates/upgrades** to the*

***VM system**.*

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image12.png){width="3.5520002187226596in"
height="3.469653324584427in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image13.png){width="3.7311089238845145in"
height="0.4663888888888889in"}

Step 4. Resize VM from Standard_B1s to Standard_B2s for better
performance for GNOME (GUI) installation, connect SSH to VM via
PowerShell, & check hardware specs to verify Standard_B2s size.

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image14.png){width="7.2397790901137355in"
height="0.56in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image15.png){width="6.5in"
height="0.5520833333333334in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image16.png){width="3.6638888888888888in"
height="3.216666666666667in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image17.png){width="3.7249956255468066in"
height="0.28in"}

*Install GNOME Desktop (Ubuntu*

*Desktop). Installation takes a few*

*minutes due to other applications*

*& packages included in GNOME*

*Desktop.*

Step 5. Reboot system to enable GNOME desktop for a Graphical User
Interface (GUI)

![A blue screen with white text Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image18.png){width="4.5886887576552935in"
height="1.0865583989501313in"}

Step 6. \*\*Generate Public SSH key via PowerShell from my laptop (not
at my desktop at the time) and insert key in Azure VM public key source
so I can continue project remotely from another device. \*\*

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image19.png){width="6.5in"
height="0.3506944444444444in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image20.png){width="6.5in"
height="2.8333333333333335in"}

-   Include Inbound Security Rule in NSG to allow my laptop's IP Address
    SSH connection then test VM connection via PowerShell.

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image21.png){width="2.104861111111111in"
height="3.1424081364829397in"}![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image22.png){width="4.208333333333333in"
height="1.7273950131233595in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image23.png){width="4.201388888888889in"
height="3.0965277777777778in"}

*I can now **SSH** connect to my*

***VM** via **laptop for flexibility.***

Step 7. After further research, resize Azure VM again from Standard_B2s
to Standard_D2s_v3 to ensure efficient performance and operations for
GNOME Desktop (GUI) environment, TeamViewer (RDP), osTicket (Ticket
System), and mySQL database.

![A black background with white text Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image24.png){width="6.5in"
height="1.1027777777777779in"}

Step 8. Download then install Remote Desktop Protocol (RDP) application
TeamViewer via PowerShell so I can enable a Graphical User Interface
(GUI) on my Azure VM.

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image25.png){width="6.5in"
height="0.17708333333333334in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image26.png){width="6.5in"
height="0.21736111111111112in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image27.png){width="6.145833333333333in"
height="0.3125in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image28.png){width="6.5in"
height="0.20069444444444445in"}

-   Start, Enable, and check the Status of TeamViewer to ensure the RDP
    app is running.

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image29.png){width="6.5in"
height="3.0701388888888888in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image30.png){width="2.875in"
height="1.7501760717410324in"}Step 8. Run TeamViewer.

> ***TeamViewer** is not responding so I started to **troubleshoot** the
> application.*

Step 9. Troubleshoot a **GUI** on a **Linux Virtual Machine** via
**PowerShell**.

![A screenshot of a computer program Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image31.png){width="5.28945428696413in"
height="5.171910542432196in"}

**Troubleshoot Steps**

-   **echo \$DISPLAY** -- displays the value of the DISPLAY
    environmental variable (GUI), however, the output was blank, so no
    display server is running

-   **sudo systemctl restart gdm3** -- restarts the GNOME Display
    Manager

-   **sudo systemctl status gdm3** -- shows the current status of gdm3
    service, the gdm3 service is active but TeamViewer is still
    unresponsive

-   **sudo systemctl status xorg** -- shows current status of xorg
    service

-   **which Xorg** -- finds location of Xorg executable

-   **sudo cat /var/log/gdm3/:0.log** -- displays content of log file
    created by the GNOME Display Manager

-   **sudo journalctl -u gdm3** -- display detailed log entries of the
    gdm3 service, the output was "no entries"

-   **export DISPLAY=:0** -- set the Display environment variable
    manually to :0

-   **startx** -- starts an X session manually

**Solution**

After troubleshooting steps, I figured out that TeamViewer will not be
compatible due to TeamViewer relying on an X server (Xorg) where a
physical display monitor is not present in an Azure Virtual Machine
environment. Also, TeamViewer requires a console user (direct physical
login) to start the X server where I am connecting with SSH via the
PowerShell output "Only console users are allowed to run the X server."

Therefore, I will be uninstalling TeamViewer & will install xRDP. xRDP
can create a virtual display for remote access that does not require
console user status login. xRDP does not rely on an X server, xRDP
creates its own virtual display session where I can access the GNOME
GUI. xRDP bypasses the need for a local display environment and a X
server, this makes the RDP application optimal for cloud environments
(Azure) where a physical display monitor is not present.

Step 10. Remove TeamViewer application from system with commands "sudo
apt remove teamviewer -y" & "sudo apt autoremove -y".

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image32.png){width="5.104166666666667in"
height="0.3020833333333333in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image33.png){width="4.354166666666667in"
height="0.3333333333333333in"}

-   Verify TeamViewer is uninstalled.

![A blue background with white text and symbols Description
automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image34.png){width="3.6666666666666665in"
height="0.53125in"}

-   Install xRDP and enable xRDP service to enable on boot.

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image35.png){width="4.479166666666667in"
height="0.2708333333333333in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image36.png){width="4.760416666666667in"
height="0.3020833333333333in"}

-   Ensure xRDP uses GNOME as the default desktop environment.

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image37.png){width="5.635416666666667in"
height="0.3541666666666667in"}

Step 11. Add Inbound Security Rule in my NSG via Azure to allow RDP
(port 3389) from my local machine.

![Screens screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image38.png){width="6.5in"
height="2.9027777777777777in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image39.png){width="4.239583333333333in"
height="2.6354166666666665in"}Step 14. On my Local Machine, open "Remote
Desktop Connection" and put my Azure VM's public IP address.

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image40.png){width="2.96875in"
height="3.609722222222222in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image41.png){width="4.227369860017498in"
height="2.3778958880139984in"}

-   ![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image42.png){width="3.302326115485564in"
    height="3.2937707786526684in"}Received login error, I will start to
    troubleshoot

-   Type "sudo cat /var/log/xrdp-sesman.log" in PowerShell via Azure VM
    to see my logs.

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image43.png){width="6.6087959317585305in"
height="0.30529746281714787in"}

![A screen shot of a computer code Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image44.png){width="6.5in"
height="0.9222222222222223in"}

-   ![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image45.png){width="1.7485509623797026in"
    height="1.9758891076115486in"}After further research, I have to
    create a password for my "TicketAdmin" user as it is a requirement
    for xRDP. I did not need to create a password when creating my Azure
    VM because I connected SSH.

![A blue screen with white text Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image46.png){width="4.676275153105862in"
height="1.0942027559055119in"}

-   Test RDP connection via Remote Desktop Connection from Local Machine

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image47.png){width="6.976744313210848in"
height="3.9227220034995627in"}

-   Successful **GNOME GUI Display** on **Ubuntu** machine via **xRDP**
    from local machine.

> ![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image48.png){width="3.544000437445319in"
> height="2.308522528433946in"}![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image49.png){width="3.64799978127734in"
> height="2.3766557305336833in"}

Step 15. Create a **second Virtual Machine** dedicated to host the **Web
Server (Apache)**, **Server-Side Scripting Language (PHP)**, and
**Database Server (MariaDB/MySQL).**

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image50.png){width="3.1520002187226597in"
height="2.8403958880139983in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image51.png){width="3.7520002187226598in"
height="1.9239271653543306in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image52.png){width="5.287193788276466in"
height="2.1323884514435694in"}

-   Connected second **Azure VM** through **SSH** on **PowerShell** then
    update.

![A screenshot of a computer screen Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image53.png){width="2.891446850393701in"
height="2.748305993000875in"}

Step 16. Install, start, and enable **Apache (Web Server)**.

![A blue screen with white text Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image54.png){width="6.5in"
height="0.9027777777777778in"}

![A blue screen with white text Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image55.png){width="6.5in"
height="0.6534722222222222in"}

Step 17. Install **PHP (Server-Side Scripting Language).**

![A blue screen with white text Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image56.png){width="6.5in"
height="0.7416666666666667in"}

Step 18. Install, start, and enable **MariaDB (Database Server).**

![A computer screen shot of a blue screen Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image57.png){width="6.5in"
height="1.2756944444444445in"}

![A blue screen with white text Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image58.png){width="6.5in"
height="0.5048611111111111in"}

Step 19. Edit MariaDM Configuration rule to allow MariaDB to allow all
connections in my Azure environment.

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image59.png){width="7.241364829396326in"
height="0.2670997375328084in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image60.png){width="4.797797462817148in"
height="0.3802023184601925in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image61.png){width="0.3020833333333333in"
height="0.3020833333333333in"}![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image63.png){width="0.3in"
height="0.30694444444444446in"}
![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image63.png){width="0.3in"
height="0.30694444444444446in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image64.png){width="4.363825459317585in"
height="0.4079997812773403in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image65.png){width="6.507409230096238in"
height="0.3244685039370079in"}

Step 20. Log into Maria DB and create a Database for osTicket for my
first VM.

![A screenshot of a computer program Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image66.png){width="5.875in"
height="1.5833333333333333in"}

-   Create dedicated Database in MariaDB for osTicket to store its data.

![A screen shot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image67.png){width="3.5416666666666665in"
height="2.3541666666666665in"}

-   Create dedicated User in MariaDB for osTicket to connect to during
    installation.

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image68.png){width="4.854166666666667in"
height="0.3541666666666667in"}

-   Grant dedicated User full access to osTicketLab Database so osTicket
    can read from and write from it.

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image69.png){width="5.552083333333333in"
height="0.3333333333333333in"}

-   Restart the privileges given.

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image70.png){width="2.8020833333333335in"
height="0.34375in"}

Creating a **MariaDB** user allows secure access to the database from
the installation stage of osTicket. This user does not interact with
**osTicket** directly but **enables osTicket** to **connect** to **Maria
DB Database**. I researched that creating **Tables** in my **MariaDB
Database** via **SQL** is **not needed** due to **osTicket**
automatically **creating the tables** for me!

Also, I found out that I need **Apache Web Server** and **PHP
Server-Side Scripting Language** on my **osTicket Application VM**, not
my **Database** where I installed those two with **MariaDB**. I learned
that a Database **does not** require a **Web Server (Apache)** or a
**Server-Side Scripting Language (PHP)** to function as its purpose is
to serve as a **Database** and **not a Web Application**.

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image71.png){width="1.3645833333333333in"
height="0.3020833333333333in"}![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image72.png){width="3.436839457567804in"
height="2.0555555555555554in"}Step 21. SSH back to VM-1 TicketSystem via
PowerShell/ RDP back to VM-1 TicketSystem via Remote Desktop
Connection/xRDP via GNOME GUI

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image73.png){width="2.0in"
height="1.832638888888889in"}

-   Install Apache Web Server via PowerShell.

```{=html}
<!-- -->
```
-   sudo apt install apache2 -y

![A blue screen with white text Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image74.png){width="6.5in"
height="0.7729166666666667in"}

-   Install PHP (Server-Side Script Language) and required extensions
    needed for osTicket to function correctly.

```{=html}
<!-- -->
```
-   sudo apt install php libapache2-mod-php php-mysql php-imap
    php-mbstring php-intl php-xml php-common php-gd php-cli -y

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image75.png){width="7.260416666666667in"
height="0.8125in"}

-   Verify Apache and PHP are working via CLI and Web Browser with GUI

```{=html}
<!-- -->
```
-   http://20.40.216.66/

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image76.png){width="3.810923009623797in"
height="2.5631944444444446in"}![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image77.png){width="3.479861111111111in"
height="2.6243055555555554in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image78.png){width="7.374891732283465in"
height="2.7395833333333335in"}

-   On a web browser in GNOME GUI, navigate to
    <https://osticket.com/download>

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image79.png){width="4.260869422572179in"
height="3.121451224846894in"}

-   Select my Plugins

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image80.png){width="6.163093832020998in"
height="2.248607830271216in"}

-   Download osTicket

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image81.png){width="4.499356955380577in"
height="2.7595713035870517in"}

-   Move the osTicket.zip file to the Apache root directory so osTicket
    can be accessed via the Apache Web Server of its root directory.

```{=html}
<!-- -->
```
-   sudo mv \~/Downloads/osTicket.zip /var/www/html

![A blue screen with white text Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image82.png){width="5.489583333333333in"
height="0.625in"}

-   Unzip the osTicket.zip file to folder /var/www/html/osticket with
    *-d* command in Apache root directory.

```{=html}
<!-- -->
```
-   sudo unzip /var/www/html/osTicketzip -d /var/www/html/osticket

-   sudo unzip /var/www/html/osTicker-v1.18.1.zip -d
    /var/www/html/osticket

![A blue screen with white text Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image83.png){width="6.5in"
height="1.0645833333333334in"}

![A screen shot of a computer screen Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image84.png){width="6.5in"
height="1.7409722222222221in"}

-   Copy default configuration template file to a new file where we will
    preserve the default template in case we need to revert back; and to
    have a separate modified configuration file where we can configure
    settings on.

```{=html}
<!-- -->
```
-   sudo cp /var/www/html/osticket/upload/include/ost-sampleconfig.php
    /var/www/html/osticket/upload/include/ost-config.php

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image85.png){width="7.967998687664042in"
height="0.32995188101487316in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image86.png){width="5.379861111111111in"
height="0.2956517935258093in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image87.png){width="1.9513068678915135in"
height="0.44347878390201223in"}

-   Give ost-config.php file read and write permissions so it can save
    and store configuration details (database credentials) during setup
    process.

```{=html}
<!-- -->
```
-   sudo chmod 0666 /var/www/html/osticket/upload/include/ost-config.php

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image88.png){width="7.681396544181977in"
height="0.35652121609798776in"}

-   Give Apache user (www-data) ownership to osTicket files so Apache
    can have the permissions to manage all osTicket files, execute
    scripts, and read/write in the osTicket directory.

```{=html}
<!-- -->
```
-   sudo chown -R www-data:www-data /var/www/html/osticket

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image89.png){width="7.097198162729659in"
height="0.30434820647419075in"}

-   Give read and execute permissions to everyone in osTicket but write
    only to the owner (Apache/www-data)

```{=html}
<!-- -->
```
-   ![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image90.png){width="5.64839457567804in"
    height="0.31304352580927386in"}sudo chmod -R 755
    /var/www/html/osticket

**Step 22.** Start the Web-Based osTicket Installation

-   ![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image91.png){width="4.547825896762904in"
    height="2.557886045494313in"}http://20.40.216.66/osticket/upload/

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image92.png){width="6.607443132108487in"
height="1.552325021872266in"}

-   I have connection errors so I will begin to troubleshoot and create
    a new Inbound Security Rule in my NSG to allow HTTP from my Azure
    TicketSystem VM

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image93.png){width="4.584722222222222in"
height="2.951419510061242in"}![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image94.png){width="3.0256944444444445in"
height="2.82994750656168in"}

-   Type <http://20.40.216.66/osticket/upload> in browser to begin
    osTicket installation.

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image95.png){width="6.160707567804025in"
height="4.495651793525809in"}

-   Input relevant information regarding System Settings, Admin User,
    and Database Settings (MariaDB).

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image96.png){width="5.177645450568679in"
height="3.821279527559055in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image97.png){width="5.25176946631671in"
height="3.9663199912510936in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image98.png){width="6.5in"
height="4.932638888888889in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image99.png){width="6.411300306211723in"
height="2.8531966316710413in"}

-   A blank page shows after installation meaning that the installation
    wasn't successful. I will begin to troubleshoot by checking Apache
    logs to find any errors.

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image100.png){width="4.301571522309711in"
height="3.341070647419073in"}

-   sudo tail -f /var/log/apache2/error.log

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image101.png){width="5.958333333333333in"
height="0.20833333333333334in"}

-   PHP Fatal Error: Connection timed out error in mysqli.php

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image102.png){width="7.494527559055118in"
height="0.6245439632545932in"}

-   ![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image103.png){width="5.958333333333333in"
    height="3.086499343832021in"}Create new Inbound Security Rule in NSG
    to allow MySQL connection. Still have PHP Fatal Error when
    attempting to install but a different log appears in error.log

```{=html}
<!-- -->
```
-   PHP Fatal Error: Access denied for user
    'TicketAdmin'@'vm.internal.cloudapp.net'

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image104.png){width="7.298611111111111in"
height="0.5208333333333334in"}

-   Go to Database VM to check on user settings for any
    misconfigurations, permissions grants, and to see if osTicket can
    access MariaDB Database via SQL.

```{=html}
<!-- -->
```
-   sudo mysql -u root -p

-   SELECT user, host FROM mysql.user

-   SHOW GRANTS FOR 'TicketAdmin@%'@'%';

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image105.png){width="3.8060728346456694in"
height="0.3959339457567804in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image106.png){width="6.5in"
height="2.3409722222222222in"}

-   Turns out the privileged user I made in MariaDB is 'TicketAdmin@%'
    and not 'TicketAdmin'. I will delete this user and create an
    appropriate user with the granted permissions necessary and better
    SQL syntax.

```{=html}
<!-- -->
```
-   DROP USER 'TicketAdmin@%'@'%';

-   CREATE USER 'TicketAdmin'@'%' IDENTIFIED BY \*\*\*;

![A blue screen with white text Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image107.png){width="6.596923665791776in"
height="1.4181485126859144in"}

-   GRANT ALL PRIVILEGES ON osTicketLab.\* TO 'TicketAdmin'@'%';

-   SHOW GRANTS FOR 'TicketAdmin'@'%';

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image108.png){width="6.5in"
height="1.9506944444444445in"}

-   Retry osTicket Web Installion... Congratulations! Troubleshooting
    was correct. ![A computer screen shot of a computer screen
    Description automatically
    generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image109.png){width="6.5in"
    height="4.800056867891514in"}

-   After installation, change permissions of "ost-config.php" file back
    to read from write as write permissions were necessary during
    installation. Also, remove installation setup directory for extra
    security.

```{=html}
<!-- -->
```
-   sudo chmod 0644 /var/www/html/osticket/upload/include/ost-config.php

-   ![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image110.png){width="7.410444006999125in"
    height="0.6694444444444444in"}sudo rm -rf
    /var/www/html/osticket/upload/setup/

> **Step 23.** Open the Web Browser of my Ubuntu GNOME GUI and navigate
> to the Admin Panel/URL then login.

-   <http://20.40.216.66/osticket/upload>

-   <http://20.40.216.66/osticket/upload/scp>

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image111.png){width="6.5in"
height="5.007638888888889in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image112.png){width="6.5in"
height="4.93125in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image113.png){width="6.5in"
height="3.061111111111111in"}

**Step 24.** Register for a domain name for my osTicket application to
later then implement HTTPS instead of HTTP to my domain with SSL
certification.

-   Go to GoDaddy.com to register for a domain name suitable for my
    ticket lab. dylanosticketlab.online

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image114.png){width="2.0885411198600177in"
height="2.62875in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image115.png){width="4.354961723534558in"
height="1.8080533683289588in"}

-   Create an **A Record** that will point my domain to my osTicket
    application VM public IP

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image116.png){width="2.006142825896763in"
height="1.3968744531933508in"}![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image117.png){width="4.93283573928259in"
height="1.5965277777777778in"}

-   Create a Virtual Host File on Apache on my osTicket VM that will
    direct domain web browser requests to my osTicket web applicatipn.

```{=html}
<!-- -->
```
-   sudo nano /etc/apache2/sites-available/dylanosticketlab.online.conf

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image118.png){width="8.370896762904637in"
height="0.2577744969378828in"}

-   Configure Virtual Host File using Apache Configuration Language
    (ACL) by applying structured syntax designed for Apache

```{=html}
<!-- -->
```
-   \<VirtualHost \*:80\>

ServerName dylanosticketlab.online

DocumentRoot /var/www/html/osticket/upload

\<Directory /var/www/html/osticket/upload\>

AllowOverride All

Require all granted

\</Directory\>

ErrorLog \${APACHE_LOG_DIR}/error.log

CustomLog \${APACHE_LOG_DIR}/access.log combined

\</VirtualHost\>

![A blue screen with white text Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image119.png){width="6.5in"
height="1.7131944444444445in"}

-   Enable Virtual Host

```{=html}
<!-- -->
```
-   sudo a2ensite dylanosticketlab.online.conf

![A blue screen with white text Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image120.png){width="6.750261373578303in"
height="1.1072561242344707in"}

-   Restart Apache

```{=html}
<!-- -->
```
-   sudo systemctl restart apache2

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image121.png){width="5.655996281714786in"
height="0.3432830271216098in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image122.png){width="5.395522747156606in"
height="1.4972156605424323in"}

An error occurred where my domain, https://dylanosticketlab.online, did
not direct to the web application of osTicket. After research, I believe
the issue is that I configured a Virtual Host File on Apache to handle
HTTP (port 80) where I need to create a Virtual Host File for HTTPS
(port 443). To have my domain only direct HTTPS traffic, I will install
**Certbot**, a command-line tool that automates obtaining and renewing
SSL/TLS certificates for websites from **Certificate Aurhority (CA)**,
**Let's Encrypt**. I will begin to troubleshoot.

**Step 25.**

-   Install Certbot with Python plugin to enable Certbot to detect and
    configure Apache Virtual Host File configuration for SSL
    certification.

```{=html}
<!-- -->
```
-   sudo apt install certbot python3-certbot-apache -y

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image123.png){width="6.5in"
height="0.8909722222222223in"}

-   Request an SSL Certificate

```{=html}
<!-- -->
```
-   sudo certbot \--apache -d dylanosticketlab.online

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image124.png){width="6.111940069991251in"
height="3.343284120734908in"}

-   Error occurred. Check logs to find the issue.

```{=html}
<!-- -->
```
-   sudo cat /var/log/letsencrypt/letsencrypt.log

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image125.png){width="5.072916666666667in"
height="0.20833333333333334in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image126.png){width="6.5in"
height="0.5534722222222223in"}

-   In NSG, create Inbound Security Rule where HTTP inbound traffic is
    allowed on port 80 to allow access from internet.

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image127.png){width="6.5in"
height="3.0625in"}

-   Update osTicket Helpdesk URL system settings with new domain
    <https://dylanosticketlab.online> from
    <http://20.40.216/osticket/upload> through the admin panel.

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image128.png){width="6.5in"
height="2.3965277777777776in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image129.png){width="6.5in"
height="2.6277777777777778in"}

-   Clear DNS record and Web Browser cache to remove the old DNS record
    and to fetch the new updated DNS record.

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image130.png){width="2.8656714785651793in"
height="2.6593438320209972in"}![A screenshot of a computer Description
automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image131.png){width="2.5749114173228347in"
height="2.6066218285214346in"}

-   Verify my domain dylaonosticketlab.online directs traffic to my
    osTicket web app.

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image132.png){width="3.6716415135608047in"
height="2.2214206036745408in"}

-   Request SSL Certificate with Certbot

```{=html}
<!-- -->
```
-   sudo certbot --apache -d dylanosticketlab.online

![A blue screen with white text Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image133.png){width="6.5in"
height="2.334722222222222in"}

-   Confirm HTTPS/SSL Certificate is implemented on my domain

```{=html}
<!-- -->
```
-   sudo ls /etc/apache2/sites-enabled/

-   sudo cat
    /etc/apache2/sites-enabled/dylanosticketlab.online-le-ssl.conf

![A computer screen shot of a blue screen Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image134.png){width="6.5in"
height="3.407638888888889in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image135.png){width="4.126388888888889in"
height="1.671641513560805in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image136.jpeg){width="3.6625in"
height="2.014925634295713in"}

-   Make a directory folder for installed plugins (audit.phar ,
    auth-2fa.phar , auth-oauth2.phar , auth-password-policy.phar) to
    access it on osTicket web application.

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image137.png){width="4.380851924759405in"
height="1.314255249343832in"}

-   sudo mkdir -p /var/www/html/osticket/upload/include/plugins

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image138.png){width="6.5in"
height="0.3902777777777778in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image139.png){width="0.6354166666666666in"
height="0.1875in"}

-   sudo mv /var/www/html/osticket/\*.phar
    /var/www/html/osticket/upload/include/plugins

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image140.png){width="6.5in"
height="0.46111111111111114in"}

-   Give the plugin files correct permissions for osTicket to access
    them

```{=html}
<!-- -->
```
-   sudo chown -R www-data:www-data
    /var/www/html/osticket/upload/include/plugins/

-   sudo chmod -R 755 /var/www/html/osticket/upload/include/plugins/

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image141.png){width="7.093003062117235in"
height="0.34479877515310586in"}

-   ![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image142.png){width="4.723880139982502in"
    height="3.0170253718285216in"}Verify through osTicket Admin Panel

**Step 27.** Install and Enable OAuth2 Plugin in osTicket Admin Panel.
My goal is to integrate Azure Active Directory (Microsoft Entra ID) as
my identity provider for osTicket.

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image143.png){width="5.5759995625546805in"
height="3.6910367454068242in"}

-   In Azure Web Portal, navigate to Microsoft Entra ID (Azure Active
    Directory) then scroll the Manage column and click App registrations

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image144.png){width="6.373507217847769in"
height="3.0839326334208224in"}

-   Register my osTicket Web Application with authentication response

-   URI (Uniform Resource Identifier),
    <https://dylanosticketlab.online/api/auth/ext/oauth2/callback>,
    through osTicket API backend routing via scripts through .php

```{=html}
<!-- -->
```
-   <https://dylanosticketlab.onle/api/auth/ext/oauth2/callback>

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image145.png){width="4.380260279965005in"
height="4.145336832895888in"}

-   Navigate to API Permissions \> Microsoft Graph \> Delegated
    Permissions, then add OpenID permissions email, openid, and profile
    then update permissions.

> ![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image146.png){width="6.35200021872266in"
> height="3.015843175853018in"}

-   Navigate to Certificates & Secrets then create a New Client Secret
    to generate/copy Client Secret Value and Client Secret ID.

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image147.png){width="6.5in"
height="3.152083333333333in"}

-   On the Admin Panel of osTicket, navigate to Manage \> Plugins \>
    Instances/ Add New Instances/ Microsoft.

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image148.png){width="6.391555118110237in"
height="4.864000437445319in"}

-   Configure and create my identity provider Microsoft 0Auth2 instance
    on osTicket.

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image149.png){width="6.5in"
height="4.358333333333333in"}

-   ![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image150.png){width="6.624985783027122in"
    height="3.4958136482939635in"}Copy and paste URI Callback Endpoint,
    Client Identifier (ID), Client Secret, Authorization URL, Access
    Token URL, User Details URL (Microsoft Graph), and Scopes from Azure
    Active Directory (Microsoft Entra ID) to osTicket 0Auth2 Plugin
    Configuration.

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image151.png){width="6.5in"
height="6.290277777777778in"}

-   Error occurs stating invalid API Endpoint. I will start to
    troubleshoot.

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image152.png){width="6.5in"
height="0.5638888888888889in"}

-   Navigate to
    <https://dylanosticketlab.online/api/auth/ext/oauth2/callback> on a
    web browser.

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image153.png){width="6.717852143482065in"
height="1.0313626421697288in"}

-   curl -I
    <https://dylanosticketlab.online/api/auth/ext/oauth2/callback>

![A computer screen with white text Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image154.png){width="6.5in"
height="1.3875in"}

The *400 Bad Request* error indicates that the osTicket API endpoint is
rejecting the request to the callback URL. The *400 Bad Request* for the
callback URL means the request is reaching my server but is not being
handled correctly. This can happen if the expected endpoint logic isn\'t
triggered or misconfiguration is present in osTicket, 0Auth2 Plugin,
Azure or Apache Web Server.

After research and with the help of the *osTicket Community Support*
forums
(<https://forum.osticket.com/d/102101-osticket-and-oauth2-plugin>), I
discovered that the issue stemmed from Apache not processing the
*.htaccess file* in the osTicket directory, which contains crucial
*rewrite rules* needed to properly *route API requests*, including those
for the callback URL. The *.htaccess file allows directory-level
configuration overrides in Apache*, enabling settings like URL rewrites
without modifying the main server configuration files. While my *Apache
Virtual Host* was already configured with *AllowOverride All* for the
osTicket directory, the .htaccess file itself was not being utilized due
to the global Apache configuration in */etc/apache2/apache2.conf*, where
*AllowOverride* was still set to *None* for the /var/www/ directory.
Updating this to *AllowOverride All* allowed Apache to *apply the
.htaccess rules*, enabling the necessary logic for handling the callback
URL dynamically and *resolving* the *400 Bad Request error*.

-   Update configuration in Apache Web Server from AllowOveride None \>
    AllowOveride All to allow osTicket to apply .htaccess rules for
    URI/URL Endpoint backend routing.

```{=html}
<!-- -->
```
-   sudo nano /etc/apache2/apache2.conf

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image155.png){width="5.6203477690288715in"
height="0.3401793525809274in"}

-   Update \<Directory /var/www/\> block from AllowOverride None to
    AllowOverride All

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image156.png){width="3.694206036745407in"
height="4.18880249343832in"}![A screenshot of a computer screen
Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image157.png){width="3.424241032370954in"
height="4.178314741907261in"}

-   Restart Apache to apply changes sudo systemctl restart apache2

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image158.png){width="5.945107174103237in"
height="0.298827646544182in"}

-   Test OAuth2 Plugin instance installation. Success!

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image159.png){width="6.5in"
height="3.058333333333333in"}

![A screenshot of a login box Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image160.png){width="4.635416666666667in"
height="4.59375in"}

**Step 28.** Create test Outlook email to configure Email settings in
osTicket Admin Panel to send outgoing email via SMTP (port 587) and
receive incoming email via IMAP (port 993).

-   Create test outlook email, dylanosticketlab@outlook.com

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image161.png){width="3.3477930883639546in"
height="3.10375in"}![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image162.png){width="3.625in"
height="2.852340332458443in"}

-   Add new email address (dylanosticketlab@outlook.com) in osTicket
    Admin email panel and configure it to support department.

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image163.png){width="6.5in"
height="5.145833333333333in"}

-   IMAP & SMTP Outlook server/port settings
    (<https://support.microsoft.com/en-us/office/pop-imap-and-smtp-settings-for-outlook-com-d088b986-291d-42b8-9564-9c414e2aa040>)

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image164.png){width="3.8020833333333335in"
height="2.5833333333333335in"}![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image165.png){width="4.159722222222222in"
height="2.3854166666666665in"}

-   Configure Remote Mailbox (IMAP) and Outgoing (SMTP) in Admin Panel
    email settings

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image166.png){width="6.5in"
height="4.7027777777777775in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image167.png){width="6.5in"
height="2.6694444444444443in"}

-   Just found out about Oauth2 for IMAP/SMTP. I will create an App
    Registration on Azure Active Directory (Microsoft Entra ID) to apply
    it.

-   Azure Portal \> Microsoft Entra ID \> App Registration \> New
    Registration \> Redirect URI -
    <https://dylanosticketlab.online/api/auth/oauth2> \> Register

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image168.png){width="4.447916666666667in"
height="3.3895833333333334in"}

-   API Permissions \> Add a permission \> Microsoft Graph \> Delegated
    Permissions \> Add permissions - IMAP.AccessAsUser.All, SMTP.Send,
    offline_access \> Grant admin consent

![A screenshot of a computer program Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image169.png){width="6.252363298337708in"
height="3.477542650918635in"}

-   Certificates & secrets \> New client secret \> Add client secret \>
    Save secret value

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image170.png){width="6.5in"
height="2.9034722222222222in"}

-   Transfer Auth/Token Endpoint, Client ID, Secret Value, Outlook
    Scopes to osTicket IMAP OAuth2 email configuration

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image171.png){width="4.745283245844269in"
height="3.04581583552056in"}![A screenshot of a computer Description
automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image172.png){width="6.118242563429571in"
height="2.7322922134733156in"}

-   After submit, complete OAuth2 process by signing into Outlook ticket
    email

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image173.png){width="4.625042650918635in"
height="3.9595691163604547in"}

-   Encountered an error where an authentication issue occurred due to
    my ticket email not being a user in my Azure Active Directory
    tenant. Will add user to fix.

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image174.png){width="4.541666666666667in"
height="4.454308836395451in"}

-   Microsoft Entra ID \> Add \> User -- Invite external user \>
    <dylanosticketlab@outlook.com> \> User type -- Member \> Review +
    Invite

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image175.png){width="4.28125in"
height="4.988194444444445in"}

-   ![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image176.png){width="4.71875in"
    height="3.9368055555555554in"}In Outlook, accept invitation

-   Accept permissions for Azure tenant member

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image177.png){width="3.1379658792650917in"
height="4.190370734908137in"}

-   Reattempt OAuth2 IMAP/SMTP config \> Accept permissions for
    IMAP/SMTP OAuth2

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image178.png){width="3.3777777777777778in"
height="4.374305555555556in"}

-   New error occurs, further troubleshooting.

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image179.png){width="6.5in"
height="0.44305555555555554in"}

-   Disable Strict Matching for testing.

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image180.png){width="6.5in"
height="2.082638888888889in"}

-   Attempt again, OAuth2 succesful

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image181.png){width="4.706280621172353in"
height="3.666352799650044in"}

-   Error occurs when I try to Save Changes, further troubleshooting.

-   5.7.3 Authentication unsuccessful
    \[DM5PR08CA0032.namprd08.prod.outlook.com 2024-12-21T01:29:36.552Z
    08DD1EBE53AB1BCE\]

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image182.png){width="3.9300568678915138in"
height="1.625in"}![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image183.png){width="4.09375in"
height="1.2351224846894138in"}

-   Unfortunately, I was not able to troubleshoot OAuth2 IMAP/SMTP error
    5.7.3 Authentication unsuccessful
    \[DM5PR07CA0059.namprd07.prod.outlook.com 2024-12-31T02:06:28.041Z
    08DD27F8C132FAE5\]. I will provide articles that pertain to this
    error. Although it is less secure, I will opt for Basic
    Authentication (Legacy) by using an App Password via Microsoft
    Outlook for IMAP/SMTP to further develop my testing lab as it isn't
    an actual production lab.

```{=html}
<!-- -->
```
-   <https://forum.osticket.com/d/101655-573-authentication-unsuccessful-ch2pr05ca0066namprd05prodoutlookcom/12>

-   <https://howtohelpdesk.com/how-to-setup-oauth-on-osticket-using-microsoft-365/>

```{=html}
<!-- -->
```
-   ![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image184.png){width="2.7359995625546807in"
    height="2.2879997812773403in"}Navigate to Microsoft Outlook Account
    settings \> Security \> Additional security options

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image185.png){width="4.336474190726159in"
height="1.9440004374453193in"}

-   Ensure Two-step verification is on \> Generate an App password \>
    Copy password

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image186.png){width="6.5in"
height="2.191666666666667in"}

![A screen shot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image187.png){width="6.5in"
height="1.632638888888889in"}

![A screen shot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image188.png){width="6.5in"
height="2.2284722222222224in"}

-   ![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image189.png){width="4.44in"
    height="2.0334339457567805in"}Error occurred. However, I believe I
    found the issue and think its my NSG not having an inbound rule to
    allow IMAP/SMTP. Very common and silly mistake.

```{=html}
<!-- -->
```
-   Navigate to Azure Web Portal \> Network Security Groups \> Inbound
    Security Rules \> Add Inbound Rule for IMAP/SMTP (Port 993/587)

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image190.png){width="6.5in"
height="2.977777777777778in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image191.png){width="6.5in"
height="2.8541666666666665in"}

-   ![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image192.png){width="5.279861111111111in"
    height="1.1055555555555556in"}Error still popped up. Enable debug
    mode in osTicket Admin Panel to see more logs

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image193.png){width="3.359722222222222in"
height="1.6388888888888888in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image194.png){width="4.481888670166229in"
height="0.47065179352580927in"}

-   Going to attempt OAuth2 with a Google Mail (Gmail) since I keep
    getting errors with Microsoft Outlook

```{=html}
<!-- -->
```
-   Navigate to Google Cloud Console with created personal Gmail and
    click "Select a project"

> ![A screenshot of a computer Description automatically
> generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image195.png){width="6.5in"
> height="3.151388888888889in"}

-   New Project

> ![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image196.png){width="3.872189413823272in"
> height="3.4056594488188976in"}
>
> ![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image197.png){width="3.7859230096237972in"
> height="3.3379844706911634in"}

-   Navigation Menu \> APIs & Services \> Library

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image198.png){width="3.080573053368329in"
height="5.813078521434821in"}

-   Gmail API in search bar of API Library

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image199.png){width="8.158344269466317in"
height="1.6316688538932633in"}

-   Click Gmail API \> Enable \> OAuth2 consent screen \> External

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image200.png){width="6.5in"
height="2.1118055555555557in"}

![A screenshot of a web page Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image201.png){width="4.559189632545932in"
height="3.077076771653543in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image202.png){width="6.5in"
height="3.0104166666666665in"}

-   Edit app registration and Add Gmail API scope
    https://mail.google.com/

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image203.png){width="8.009060586176728in"
height="2.2879997812773403in"}![A screenshot of a computer Description
automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image204.png){width="6.5in"
height="4.577083333333333in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image205.png){width="4.792000218722659in"
height="2.568081802274716in"}

-   Add my ticket lab Gmail account as a Test User and check Summary

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image206.png){width="6.5in"
height="2.6534722222222222in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image207.png){width="4.946406386701662in"
height="2.8156463254593174in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image208.png){width="4.0744619422572175in"
height="2.7385094050743657in"}

-   Navigate to APIs & Services \> Credentials \> Click +Create
    Credentials \> Click OAuth client ID

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image209.png){width="6.5in"
height="2.3368055555555554in"}

-   Application Type is Web Application \> Add Name to "osTicket OAuth2
    IMAP/SMTP" \> Add
    *<https://dylanosticketlab.online/api/auth/oauth2>* in Authorized
    Redirected URIs \> Create

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image210.png){width="4.610095144356955in"
height="5.055837707786527in"}

-   Once OAuth2 Client is created, copy the generated Client ID and
    Client Secret as these value strings will be needed to
    copy/configure in OAuth2 in the osTicket web application.

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image211.png){width="4.8419991251093615in"
height="6.128155074365704in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image212.png){width="4.9120002187226595in"
height="2.148943569553806in"}![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image213.png){width="6.5in"
height="0.5451388888888888in"}

-   Add Gmail account *dylanticketlab@gmail.com* in osTicket Admin Panel
    and configure it to be default system email

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image214.png){width="4.168527996500438in"
height="3.56952646544182in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image215.png){width="5.719027777777778in"
height="2.1843503937007873in"}

-   Click on <dylanticketlab@gmail.com> email address and configure the
    Account, Remote Mailbox (IMAP), and Outgoing (SMTP)

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image216.png){width="3.548956692913386in"
height="2.24240813648294in"}![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image217.png){width="4.70400043744532in"
height="1.485077646544182in"}

-   ![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image218.png){width="3.544000437445319in"
    height="2.671422790901137in"}Hostnames: IMAP -- imap.gmail.com:993 /
    SMTP -- smtp.gmail.com:587

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image219.png){width="4.204694881889764in"
height="2.4094236657917762in"}

-   Configure Authentication for OAuth2 -- Google and allow access for
    dylanosticketlab.online to access data to my Gmail
    dylanticketlab@gmail.com

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image220.png){width="4.034520997375328in"
height="2.1759995625546806in"}![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image221.png){width="4.33166447944007in"
height="1.08in"}![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image222.png){width="4.343281933508312in"
height="3.52in"}![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image223.png){width="4.04833552055993in"
height="2.76in"}

-   Submit OAuth2 configuration changes and save changes. It works! The
    error was likely that Outlook had more compatability issues with
    osTicket and Microsoft overall stricter security measures on smaller
    applicaions like osTicket. OAuth2 with Gmail was sucessful as it
    seems oftern easier and more reliable for small-scale setups like
    osTicket labs because of Google's simplified API and broad
    compatibility.

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image224.png){width="4.221360454943132in"
height="2.9520002187226595in"}![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image225.png){width="3.9664173228346455in"
height="3.0240004374453195in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image226.png){width="6.197555774278215in"
height="2.711999125109361in"}

-   Now that OAuth2 for IMAP/SMTP is implemented. I will create test
    users to test OAuth2 staff sign in. (I know that it would have made
    more sense to test OAuth2 staff sign right after I implemented that
    part instead of testing after I implmented OAuth2 on IMAP/SMTP.)

```{=html}
<!-- -->
```
-   Create Test Users in Microsoft Azure \> Microsoft Entra ID \> Users
    \> + New user \> Create new user

> ![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image227.png){width="2.2761187664041995in"
> height="3.2082797462817148in"}![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image228.png){width="4.574305555555555in"
> height="2.432638888888889in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image229.png){width="2.2164173228346455in"
height="3.2235181539807525in"}![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image230.png){width="5.298507217847769in"
height="1.6954090113735782in"}![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image231.png){width="4.95522419072616in"
height="1.9421620734908136in"}

-   ![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image232.png){width="3.529166666666667in"
    height="3.5368055555555555in"}Test OAuth2 Azure sign in on
    <https://dylanosticketlab.online/scp>. Error occurs where I press
    the "Sign in with Azure" directs me to
    <https://dylanosticketlab.online> end user page, will start to
    troubleshoot.

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image233.png){width="3.6927548118985127in"
height="2.388059930008749in"}

-   After looking around, I believe the issue stems from
    misconfigurations in my osTicket OAuth2 plugin and Azure AD App
    Regisration/Authentication. I updated redirect URI on both Azure AD
    App Registration/Authentication and osTicket OAuth2 plugin.

-   <https://dylanosticketlab.online/api/auth/oauth2>
    <https://dylanosticketlab.online/osticket/upload/scp/auth/oauth2>
    (also change Authentication Target from Agents and End Users to
    Agents Only in osTicket)

> ![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image234.png){width="3.929650043744532in"
> height="2.9149103237095364in"}![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image235.png){width="4.430955818022747in"
> height="2.5188681102362205in"}

-   ![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image236.png){width="4.030182633420822in"
    height="4.849568022747157in"}Test Azure OAuth2 sign in. An error
    occurred so I will start to troubleshoot by checking Apache logs.

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image237.png){width="3.9245286526684167in"
height="4.742730752405949in"}

-   ![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image238.png){width="6.745283245844269in"
    height="2.1756944444444444in"}sudo tail -f
    /var/log/apache2/error.log

-   PHP Warning: require(client.inc.php): Failed to open stream and PHP
    Fatal Error: Uncaught Error: Failed opening required
    'client.inc.php' shows that the *client.inc.php* file is not found
    in *dispatcher.php* and will not be able to execute the script
    causing a fatal error in Apache logs.

-   The osTicket system relies on client.inc.php for client-related
    operations. The dispatcher.php file is a critical part of handling
    client requests (e.g., for authentication, including OAuth2
    callbacks). If client.inc.php cannot be loaded, all dependent
    functionalities will fail, including OAuth2 authentication.

-   Confirm the *client.inc.php* file is in my directory

-   sudo find /var/www/html -name \"client.inc.php\"

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image239.png){width="6.622642169728784in"
height="0.48055555555555557in"}

-   client.inc.php file exists in my system but the location is in the
    wrong path/location where dispatcher.php is having trouble includng
    it. I will run sudo nano on dispatcher.php to configure and update
    the correct path/location to client.inc.php

-   sudo nano /var/www/html/osticket/upload/apps/dispatcher.php

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image240.png){width="6.5in"
height="0.39166666666666666in"}

-   update require('client.inc.php'); to correct path/location
    require(\'../client.inc.php\');

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image241.png){width="6.113207567804024in"
height="4.898611111111111in"}

\- sudo systemctl restart apache2

\- Test with *curl -I*
[*https://dylanosticketlab.online/osticket/upload/scp/auth/oauth*2](https://dylanosticketlab.online/osticket/upload/scp/auth/oauth2)

-   Errors 404 still occurs, I will enable PHP log_errors to further
    see.

![A screen shot of a computer code Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image242.png){width="6.5in"
height="1.2694444444444444in"}

-   sudo nano /etc/php/8.3/apache2/php.ini

-   Change log_erros Default Value from Off On

-   sudo tail -f /var/log/php_errors.log

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image243.png){width="4.272916666666666in"
height="2.9555555555555557in"}

-   Couldn't find php_error.logs but may have a new fix I am going to
    try.

-   Navigate to *php.ini* file to configure/update "include_path"
    setting. The include_path determines where PHP looks for files
    included via require or include statements. By default, it is
    limited to the current directory (.) and the system-wide PHP library
    path (/usr/share/php). Updating the include_path ensures PHP can
    locate additional files, such as client.inc.php in my osTicket
    setup.

-   sudo nano /etc/php/8.3/apache2/php.ini
    ![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image244.png){width="6.5in"
    height="0.26180555555555557in"}

-   Update include_path line to include my osTicket directory from
    include_path = \".:/usr/share/php\" to include_path =
    \".:/usr/share/php:/var/www/html/osticket/upload\"

> ![A computer screen with a blue background Description automatically
> generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image245.png){width="6.5in"
> height="4.883333333333334in"}

-   After researching and troubleshooting the OAuth2 authentication for
    staff sign-ins in your osTicket lab, it seems the issues are likely
    due to routing or plugin registration errors. Despite setting up
    Apache, .htaccess, and the OAuth2 plugin correctly, the
    /scp/auth/oauth2 endpoint isn\'t resolving as expected. This could
    be caused by the auth-oauth2.phar plugin failing to register routes
    properly, incorrect PHP include_path settings or missing
    dependencies, or even routing errors within dispatcher.php. Solving
    these issues would require a deep dive into the plugin code and
    osTicket's internal routing logic, which may not align with the
    goals of your lab at this time. I observed these errors while
    reviewing Apache error logs and testing the endpoint via curl
    commands.

```{=html}
<!-- -->
```
-   So the goal with OAuth2 Azure Staff sign in was to implement MFA
    (Multi-Factor Authentication) and password management policy in the
    Azure Microsoft Entra ID setup. However, due to errors that beyond
    my scope of technical skills I will opt for "Two Factor
    Authenticator (MFA)" and "Password Management Policies" plugins I
    had installed during the initial installtion of osTicket.

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image246.png){width="5.270570866141732in"
height="2.8520778652668417in"}

-   Install Two Factor Authenticator \> Status = Active \> Save Changes

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image247.png){width="4.8in"
height="3.961828521434821in"}

-   Instances \> Add New Instance \> Name = "2FA for Staff" \> Status =
    "Enabled" \> Config Tab \> Issuer = Dylan TicketLab \> Save Changes
    & Add Instance

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image248.png){width="6.5in"
height="3.7333333333333334in"}

![A screenshot of a computer program Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image249.png){width="6.5in"
height="2.5055555555555555in"}

-   Since OAuth2 Azure staff sign (Users) was not functioning, I will
    create users/agents via osTicket and enable 2FA (MFA) directly on
    the osTicket web app.

-   Admin Panel \> Agents \> Add New Agent

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image250.png){width="5.785001093613299in"
height="2.273208661417323in"}

-   Fill in required details \> Set Allowed Access to Departments \>
    Grant Permissions to given role \> Assign Agent a Team \> Create
    Agent

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image251.png){width="3.7206178915135606in"
height="1.7887587489063868in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image252.png){width="3.557638888888889in"
height="2.4770833333333333in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image253.png){width="3.747536089238845in"
height="2.12in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image254.png){width="4.768000874890639in"
height="1.71209864391951in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image255.png){width="2.76in"
height="0.9107075678040245in"}

-   Implement Password Policy plugin in osTicket

```{=html}
<!-- -->
```
-   Admin Panel \> Manage \> Plugins \> +Add New Plugin \> Install
    Password Management Policies

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image256.png){width="6.5in"
height="2.423611111111111in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image246.png){width="4.651708223972004in"
height="2.517191601049869in"}

-   Plugins \> Password Management Policies \> Status = Active \>
    Instances Tab \> + Add New Instance \> Set Name \> Status = Enabled

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image257.png){width="6.672795275590551in"
height="2.0695647419072616in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image258.png){width="6.5in"
height="2.5590277777777777in"}

-   Configure Tab \> Configure Password Requirment Settings \> Minimum
    Length = 8, Maximum Length = 40, Character Class Required = 3,
    Password Strength = Strong (80 bits), Enforce on login = Enabled,
    Password Reuse = Disabled, Password Expiration = 90 days \> Add
    Instance

![A screenshot of a computer screen Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image259.png){width="6.5in"
height="4.658333333333333in"}

-   Logout of osTicket and test Password Management Policy

![A login screen with a kangaroo logo Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image260.png){width="1.5902646544181978in"
height="1.6203401137357831in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image261.png){width="4.032081146106736in"
height="2.312846675415573in"}

-   Change old password to meet password policy requirement

![A screenshot of a login box Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image262.png){width="2.5626574803149604in"
height="1.3478576115485563in"}

-   Change password again incorrectly to see password requiement errors

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image263.png){width="2.3833333333333333in"
height="1.6215277777777777in"}

-   Password Management Policy Implementation is successful!

```{=html}
<!-- -->
```
-   I will now enforce a policy to require agents/staff to turn on
    Multifactor Authentication (2FA) onto their accounts.

```{=html}
<!-- -->
```
-   Admin Panel \> Settings \> Agents \> Configure Authentication
    Settings to enforce my Password Management Policy and enable
    Multifactor Authentication for Agents \> Save Changes

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image264.png){width="6.5in"
height="4.561111111111111in"}

-   As soon as I applied the MFA (2FA) changes, osTicket required me to
    configure and save Two Factor Authentication.

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image265.png){width="4.08in"
height="2.2653576115485565in"}

-   On the Email option of "Manage 2FA Options", email verifcaiton codes
    were not being sent and I could not navigate through the osTicket
    web app due to 2FA policy. I will attempt to trouble shoot through
    trying to get access back with the Authenticator 2FA option.

![A screen shot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image266.png){width="6.010416666666667in"
height="1.80080927384077in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image267.png){width="5.989583333333333in"
height="2.133050087489064in"}

-   (No verification email code received)

-   Click Authenticator on Manage 2FA Options

-   Scan QR Code of Authenticator application (Microsoft or Google
    Authenicator) of your choice and enter the six number code from
    Auhtenticator application

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image268.png){width="5.78125in"
height="3.419128390201225in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image269.jpeg){width="2.5902777777777777in"
height="5.068384733158355in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image270.png){width="5.319594269466316in"
height="1.9930555555555556in"}

-   Authenicator app 2FA is successful!

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image271.png){width="6.5in"
height="2.0215277777777776in"}

-   Save changes in osTicket account profile

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image272.png){width="4.214942038495188in"
height="2.9509109798775155in"}

-   Logout and see if 2FA (MFA) changes are applied on staff/agent login

![A screenshot of a phone Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image273.png){width="4.363377077865267in"
height="4.657649825021872in"}

-   Implementation of 2FA (MFA) with Authenticator app is successful!

```{=html}
<!-- -->
```
-   Now to test receieving tickets. I had my brother sent a test ticket
    at my osTicket end user web page <https://dylanosticketlab.online>.

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image274.png){width="5.182125984251969in"
height="2.1940791776027995in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image275.png){width="4.9783617672790905in"
height="3.4880435258092737in"}![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image276.png){width="4.977777777777778in"
height="3.303229440069991in"}

-   Retrieving tickets through the osTicket web application works!
    However, my dedicated ticket lab email <dylanticketlab@gmail.com> is
    not receiving email via Gmail nor the sender is receiving emails
    when I respond a message back to the sender on
    <https://dylanosticketlab.online/scp> agent ticket panel. I will
    start to troubleshoot by checking Google Cloud Platform OAuth2
    IMAP/SMTP configuations to ensure email settings are correct or
    needs to be changed/updated.

-   Check OAuth2 Consent screen in Google Cloud Platform Console \> Edit
    App \> Scopes \> Add Scopes

![A screen shot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image277.png){width="6.112319553805774in"
height="2.72376968503937in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image278.png){width="6.176353893263342in"
height="3.034067147856518in"}

-   Select and update scopes
    <https://www.googleapis.com/auth/userinfo.email> and
    <https://www.googleapis.com/auth/userinfo.profile>

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image279.png){width="2.359870953630796in"
height="3.4433956692913386in"}![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image280.png){width="3.849057305336833in"
height="3.453757655293088in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image281.png){width="6.5in"
height="1.9805555555555556in"}

-   After updating scopes in Google Cloud Platform, navigate to osTicket
    to apply scope updates in Admin Panel \> Emails \> Click default
    ticket lab email \> Remote Mailbox \> Authentication Configuration
    \> Update Scopes \> Submit \> Allow dylanosticketlab.online access
    to my ticket gmail account

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image282.png){width="4.8636472003499565in"
height="2.1569444444444446in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image283.png){width="4.907510936132983in"
height="2.763620953630796in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image284.png){width="6.5in"
height="0.9451388888888889in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image285.png){width="6.5in"
height="1.5840277777777778in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image286.png){width="5.679245406824147in"
height="4.348964348206474in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image287.png){width="3.896340769903762in"
height="3.0150853018372703in"}

-   Enable IMAP in Gmail \> Settings \> Forwarding and POP/IMAP \>
    Enable IMAP Status \> Save Changes

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image288.png){width="5.301886482939633in"
height="2.6877613735783026in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image289.png){width="3.85625in"
height="0.6319444444444444in"}

-   Send a test email to check if emails are being sent/received via
    email inbox

-   Admin Panel \> Emails \> Diagnostic \> Test Outgoing Email with
    personal email

-   SMTP/IMAP is now succesful! 2FA (MFA) should now be accesbile via
    email for staff.

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image290.png){width="6.671078302712161in"
height="4.931324365704287in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image291.png){width="6.2648862642169725in"
height="4.489910323709537in"}

-   Create a Standard & Critical SLA for my ticket lab

```{=html}
<!-- -->
```
-   Admin Panel \> Manage \> SLA \> Add New SLA Plan \> Set up SLA Name
    \> Status: Active \> Grace Period \> Schedule: 24/7 \> Add Plan

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image292.png){width="6.5in"
height="2.204861111111111in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image293.png){width="6.5in"
height="3.7784722222222222in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image294.png){width="6.5in"
height="4.504166666666666in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image295.png){width="6.5in"
height="1.8159722222222223in"}

-   Create a Level II Support Team

-   Admin Panel \> Agents \> Teams \> Add a New Team \> Set Name \>
    Status: Active \> Create Team

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image296.png){width="6.5in"
height="2.348611111111111in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image297.png){width="6.5in"
height="4.450694444444444in"}

-   Assign Departments, SLA Plans, Level Support Teams, and General
    Settings of Ticket Category Help Topics

```{=html}
<!-- -->
```
-   Admin Panel \> Help Topics \> Configure Ticket Options for Feedback,
    General Inquiry, Report a Problem, and Report a Problem / Access
    Issues

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image298.png){width="6.5in"
height="2.9493055555555556in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image299.png){width="6.5in"
height="4.129166666666666in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image300.png){width="5.54411854768154in"
height="4.039623797025372in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image301.png){width="5.559378827646544in"
height="3.6278510498687666in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image302.png){width="6.5in"
height="4.751388888888889in"}

-   Now to finalize my project with a password change to the Test User I
    created.

```{=html}
<!-- -->
```
-   Admin Panel \> Agents \> Test User \> Set Password \> Send the agent
    a password reset email \> Update

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image303.png){width="5.5744958442694665in"
height="2.3030522747156605in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image304.png){width="6.5in"
height="4.094444444444444in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image305.png){width="6.5in"
height="2.745138888888889in"}

-   Unfortunately, I forgot the Gmail password of the first test user
    and I am not on the device where I made the accout. So, I will
    create a new Gmail user.

-   ![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image306.png){width="4.527777777777778in"
    height="2.2083333333333335in"}Create new password for new created
    user then test.

-   Test login, create password, and do MFA policy (will try Email 2FA
    for testing purposes)

![A screenshot of a login page Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image307.png){width="4.273323490813648in"
height="4.364394138232721in"}

![A screenshot of a computer screen Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image308.png){width="6.5in"
height="3.357638888888889in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image309.png){width="6.5in"
height="1.8020833333333333in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image310.png){width="6.5in"
height="2.142361111111111in"}

-   Did not receive any mail. Started to troubleshoot and believe the
    problem is an outdated token in Oauth2 IMAP configuration. Will
    delete and renew.

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image311.png){width="6.5in"
height="2.814583333333333in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image312.png){width="6.5in"
height="2.50625in"}

-   Test MFA policy with email

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image313.png){width="6.5in"
height="2.3381944444444445in"}

-   SUCCESS!!!

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image314.png){width="6.5in"
height="5.055555555555555in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image315.png){width="6.5in"
height="2.296527777777778in"}

-   Test password reset.

![A screenshot of a login box Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image316.png){width="6.5in"
height="6.706944444444445in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image317.png){width="6.5in"
height="4.459722222222222in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image318.png){width="6.5in"
height="5.353472222222222in"}

-   Received password reset email

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image319.png){width="6.5in"
height="2.7305555555555556in"}

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image320.png){width="6.5in"
height="2.678472222222222in"}

-   Lastly, simulate a practical ticket workflow scenario via password
    reset request.

```{=html}
<!-- -->
```
-   Navigate to <https://dylanosticketlab.online> \> Open a New Ticket
    \> Fill Contact Information, Help Topic, and Ticket Details \>

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image321.png){width="6.5in"
height="3.845138888888889in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image322.png){width="6.5in"
height="7.803472222222222in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image323.png){width="6.5in"
height="4.179166666666666in"}

-   Verify Ticket was received via osTicket Agent Panel and dedicated
    email

![A screenshot of a email Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image324.png){width="6.5in"
height="3.95625in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image325.png){width="6.5in"
height="4.713888888888889in"}

-   Claim Ticket in Agent Panel, respond to Ticket's request, send
    password change reset link, and wait for user to respond back to
    resolved ticket.

![](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image326.png){width="5.009433508311461in"
height="4.184936570428697in"}

-   Admin Panel \> Agents \> Test User2 \> Set Password \> Send Agent
    password reset email \> Update

> ![A screenshot of a computer Description automatically
> generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image327.png){width="6.5in"
> height="3.6631944444444446in"}

-   Verify User received password change reset and applied it

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image328.png){width="6.5in"
height="2.3328357392825896in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image329.png){width="6.5in"
height="3.654222440944882in"}

![A screenshot of a computer Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image330.png){width="6.5in"
height="2.0966021434820648in"}

-   Resolve Ticket test

![A screenshot of a chat Description automatically
generated](vertopal_ada8ca9ef3ce4a1580dd26cff0bd1396/media/image331.png){width="6.5in"
height="6.327490157480315in"}

-   My lab is done. Thank you
